import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

REPO = Path('/workspace/QuelleHeureEst-Il.com')
ROOT = Path('/workspace/.cloud-setup/pr179')
BUILD = ROOT / 'build'
EVIDENCE = ROOT / 'evidence'
BEFORE = 'b7c96646ef7a00a048b646918be5f2547b479426'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)

def tree(ref):
    result = {}
    for entry in git('ls-tree', '-rz', ref).split(b'\0'):
        if entry:
            meta, path = entry.split(b'\t', 1)
            mode, kind, blob = meta.decode().split()
            assert kind == 'blob'
            result[path.decode()] = {'mode': mode, 'blob': blob}
    return result

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

BUILD.mkdir(exist_ok=True)
EVIDENCE.mkdir(exist_ok=True)
assert not list(BUILD.iterdir())
head = git('rev-parse', 'HEAD').decode().strip()
baseline, candidate = tree(BEFORE), tree(head)
assert all(candidate.get(p) == v for p, v in baseline.items())
assert set(candidate) - set(baseline) == {'src-tauri/icons/icon.png'}
assert candidate['src-tauri/icons/icon.png']['blob'] == 'fde760bc8173080d1ca767a2cd217c9317e902ab'
for path, item in candidate.items():
    data = subprocess.check_output(['git', 'cat-file', '--filters', f'{head}:{path}'], cwd=REPO)
    assert data == (REPO / path).read_bytes(), path
    destination = BUILD / path
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(data)
    destination.chmod(int(item['mode'], 8) & 0o777)
    item['sha256'] = hashlib.sha256(data).hexdigest()
snapshot = {'before_sha': BEFORE, 'candidate_sha': head, 'preserved_files': len(baseline), 'files': candidate}
(EVIDENCE / 'preservation-before.json').write_text(json.dumps(snapshot, indent=2) + '\n')

env = dict(os.environ)
env.update(CI_HEAD_SHA=head, CI_BASE_SHA='3e1f4177d2c1417b62121559ec9f39e8ca342394', SOURCE_SHA='3e1f4177d2c1417b62121559ec9f39e8ca342394', EVIDENCE_DIR=str(EVIDENCE), BUILD_DIR=str(ROOT / 'historical-guard-build'))
Path(env['BUILD_DIR']).mkdir(exist_ok=True)
with (EVIDENCE / 'historical-guard.log').open('w') as log:
    guard = subprocess.run(['python3', 'docs/validation/rust-176/check.py', 'before'], cwd=REPO, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=60)
assert guard.returncode != 0

commands = [
    ('resolution', 180, ['cargo', 'generate-lockfile', '--verbose']),
    ('install', 600, ['pnpm', 'install', '--frozen-lockfile', '--store-dir', '/workspace/.cloud-setup/cache/pnpm', '--fetch-retries=1', '--fetch-timeout=20000']),
    ('dependency-graph', 60, ['node', 'docs/validation/rust-178/check-ported-graph.cjs']),
    ('frontend', 180, ['pnpm', 'run', 'vite:build']),
    ('build-debug', 900, ['cargo', 'build', '--workspace', '--locked', '--verbose']),
    ('test-debug', 900, ['cargo', 'test', '--workspace', '--locked', '--verbose']),
    ('build-release', 900, ['cargo', 'build', '--workspace', '--release', '--locked', '--verbose']),
    ('test-release', 900, ['cargo', 'test', '--workspace', '--release', '--locked', '--verbose']),
]
results = {'candidate_sha': head, 'historical_guard_exit': guard.returncode, 'commands': {}}
for name, bound, command in commands:
    start = time.monotonic()
    print(f'START {name}: {command}', flush=True)
    with (EVIDENCE / f'{name}.log').open('w') as log:
        process = subprocess.run(['timeout', '--kill-after=10s', f'{bound}s', *command], cwd=BUILD, env=env, stdout=log, stderr=subprocess.STDOUT)
    results['commands'][name] = {'command': command, 'exit_code': process.returncode, 'seconds': round(time.monotonic() - start, 2), 'log_sha256': digest(EVIDENCE / f'{name}.log')}
    if name == 'resolution' and process.returncode == 0:
        lock = (BUILD / 'Cargo.lock').read_bytes()
        (EVIDENCE / 'Cargo.lock').write_bytes(lock)
        results['cargo_lock_sha256'] = hashlib.sha256(lock).hexdigest()
    (EVIDENCE / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
    print(f'END {name}: {results["commands"][name]}', flush=True)

failures = []
for path, item in candidate.items():
    for directory in (REPO, BUILD):
        if digest(directory / path) != item['sha256']:
            failures.append(str(directory / path))
assert not (REPO / 'Cargo.lock').exists()
lock_unchanged = (BUILD / 'Cargo.lock').read_bytes() == (EVIDENCE / 'Cargo.lock').read_bytes()
results['preservation'] = {'failures': failures, 'preserved_existing_files': len(baseline), 'temporary_lock_unchanged': lock_unchanged}
(EVIDENCE / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
assert not failures and lock_unchanged
print('PRESERVATION PASS', flush=True)
