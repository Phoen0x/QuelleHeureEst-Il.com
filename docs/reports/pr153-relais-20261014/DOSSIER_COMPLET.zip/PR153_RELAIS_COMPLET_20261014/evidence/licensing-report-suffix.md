
Le hash `0x2ca1d603` a été calculé sur **le texte LICENSE existant**, avec la normalisation cargo-deny (fins de lignes LF, LF final) et XxHash32 seed 0, après contrôle de deux vecteurs connus. SHA-256 du texte normalisé : `f982c2f3d05acc6eba0f6e447106270850faf4bbcec0d4702fb66914b7dcc34f`. Preuves de l'algorithme : [lecture des fichiers](https://github.com/EmbarkStudios/cargo-deny/blob/0.20.2/src/licenses/gather.rs), [fonction hash](https://github.com/EmbarkStudios/cargo-deny/blob/0.20.2/src/lib.rs). XxHash32 n'est pas un hash cryptographique ; le SHA/blob servent à tracer l'origine. `../LICENSE` est relatif à la racine du paquet `src-tauri`.

Le nom `LicenseRef-Phoen0x-Proprietary` identifie le texte actuel, **sans le modifier ni créer une nouvelle autorisation juridique**. Il ne doit être accepté qu'après confirmation par le titulaire. La métadonnée Cargo éventuelle `license-file = "../LICENSE"` serait une autre modification, soumise à accord ; ajouter `license = "MIT"` ou `"Unlicense"` serait un changement juridique injustifié.

Choix volontaire : `private.ignore=false` maintient le contrôle de l'application. L'alternative `private.ignore=true` serait plus large et cacherait les erreurs de futures racines privées ; elle n'est pas recommandée comme solution minimale. Aucun `exclude`, seuil réduit ou accord général OSI/FSF n'est proposé. `include-dev=true` étend le contrôle au lieu de l'affaiblir. Les exceptions sont limitées aux versions actuelles ; des changements de version/textes devront être revus. Les checks advisories/bans/sources restent distincts et ne sont pas neutralisés.

### 7. Conséquences opérationnelles avant acceptation

1. **Permissives** : documenter les choix OR, produire les notices/licences tierces réellement nécessaires pour chaque artefact, conserver NOTICE et marqueurs de modifications requis. L'allowlist ne produit pas ces fichiers.
2. **MPL** : prévoir l'accès aux sources exactes couvertes, aux modifications et aux notices pour les destinataires ; vérifier l'EULA. Autoriser les cinq paquets sans ce processus ne vaut pas conformité.
3. **Application** : confirmer le régime propriétaire, les ayants droit et les autorisations de distribution ; traiter la contradiction documentaire et la portée du CLA séparément, avec accord. La licence réservée actuelle ne démontre pas que tous les utilisateurs ont déjà un droit de distribution.
4. **Natif/platformes** : établir la liste effective des bibliothèques/versions et de leur mode de liaison par cible ; vérifier les obligations LGPL si pertinentes, OpenSSL selon version, SDK et contenu des bundles. Ne pas extrapoler la licence du crate wrapper.
5. **Archives/code fantôme** : aucune suppression/réactivation. Leur absence d'un exécutable ne supprime pas les obligations applicables à une éventuelle redistribution du dépôt source et des archives. Préserver les notices et provenances des variantes historiques.
6. **Usage interne** : les obligations de mise à disposition de sources liées à la distribution ne se déclenchent généralement pas par le seul usage interne. Les restrictions d'utilisation, droits de brevet/marque, copies et redistributions à des tiers restent à examiner ; « usage interne » ne signifie pas licence inexistante.

### 8. Vérifications réellement effectuées et limites

- Lecture des instructions AGENTS.md, README et prompt ; inspection des textes propriétaires et MIT vendored, sans modifications.
- Extraction du journal CI, contrôle des **450 diagnostics exacts** et du rejet applicatif ; aucune classification fondée uniquement sur le statut rouge.
- Parsing du Cargo.lock et rapprochement exhaustif : **490/490 identifiants registry uniques couverts**, plus l'application ; absence de doublon/missing dans ce rapprochement, versions avec suffixes conservées.
- Lecture de 40 manifestes amont de même nom/version et héritages workspace, ainsi que des textes de ring 0.17.14.
- Lecture du comportement et de la syntaxe de cargo-deny **0.20.2** et du parseur SPDX **0.13.4**.
- **Parsing TOML réussi** de la proposition hors dépôt ; évaluation logique indépendante des 490 expressions : sept exigences => **485 satisfaites, cinq MPL restantes**. Ce calcul n'est pas une exécution du moteur cargo-deny ni une validation juridique.
- Aucun `cargo`, `rustc` ou `cargo-deny` local disponible. **La proposition n'a pas été exécutée avec cargo-deny** et aucun nouveau workflow n'a été déclenché. Les résultats CI cités sont ceux du run existant, pas d'une configuration proposée.
- Aucun contrôle Android/StackBlitz/Cursor/Claude ni vérification juridique intégrale des APK/bundles natifs n'est revendiqué. Les configurations de ces outils, dépendances optionnelles, verrous historiques, archives et rétroports restent intacts.

Validation future, **après accord**, dans une copie isolée : moteur exact 0.20.2, lock gelé, configuration proposée, contrôle licence puis tous les checks ; examen explicite des graphes/features/cibles supportés. Vérifier la reconnaissance de la clarification/du hash, le graphe dev/build, les sources natives et les notices des artefacts. Une analyse all-features peut demander une matrice si certaines variantes sont incompatibles entre elles ; ne pas les retirer.

### 9. Décisions humaines et verdict

Accord explicite nécessaire avant :
- l'ajout de toute politique cargo-deny, même permissive ;
- les cinq acceptations MPL et leur procédure de sources/EULA ;
- la clarification du paquet propriétaire et toute métadonnée de licence ;
- toute correction des documents juridiques/contradictions, après confirmation des droits et du mode de distribution.

**Verdict : échec de licences expliqué et proposition concrète préparée ; conformité de distribution et succès cargo-deny non encore validés.** Les 450 rejets ne démontrent pas 450 incompatibilités. Aucun paquet ne doit être supprimé pour obtenir un audit vert. La PR ne doit pas être déclarée prête à fusionner sur la seule base de cet audit ; le check demeure en échec tant qu'une politique n'est pas décidée/appliquée/validée, et les advisories sont un autre blocage.

**EN:** Read-only licence audit of PR #153 at the pinned commit. All 490 registry package/version declarations and the application's missing machine metadata are inventoried. The 450 observed registry rejections result from an empty default allowlist. Five MPL-only versions require a source-compliance process; application proprietary metadata and contradictory documentation require owner decisions. The scoped policy above is an unapplied proposal, not a successful cargo-deny run or a certification of native-binary compliance. No repository changes, dependency removals, workflow/policy changes or merge were performed.

