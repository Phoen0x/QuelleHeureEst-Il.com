from pathlib import Path
import json, shutil, hashlib, zipfile, re, datetime

root = Path('/workspace')
out = root / 'PR153_RELAIS_COMPLET_20261014'
out.mkdir(exist_ok=True)
intro = (root/'pr153-handoff-introduction.md').read_text()
intro = intro.replace('les497? **Attention : le chiffre correct est491 entrées, pas497.** Le nombre de résultats SARIF est indépendant.', 'les **491 entrées du lock (490 registry + application)**. Le nombre de résultats SARIF est indépendant.')
fixes = {
 'les14commentaires':'les 14 commentaires', 'des14commentaires':'des 14 commentaires', 'de14commentaires':'de 14 commentaires',
 'toujours14commentaires':'toujours 14 commentaires', 'toujours14commentaires':'toujours 14 commentaires', 'les3parties':'les 3 parties', '3partiesoriginales':'3 parties originales',
 'les40':'les 40', 'pour ces40':'pour ces 40', '450diagnostics':'450 diagnostics', '40sourcesamontnonvérifiéespar téléchargementarchive':'40 sources amont non vérifiées par téléchargement des archives',
 'les491':'les 491', 'aux491':'aux 491', 'les490':'les 490', 'les5':'les 5',
 'seed0':'seed 0', 'vecteurs empty0x':'vecteurs empty 0x', 'et a0x':'et a 0x', 'CF':'CF',
 'pasrésolu':'pas résolu', 'dossierconsolidé':'dossier consolidé', 'rapportconsolidé':'rapport consolidé', 'rapportlicencesoriginal':'rapport licences original',
 'licencesoriginal':'licences original', 'licencesregistryactives':'licences registry actives', 'registreactif':'registre actif',
 'mêmeSHA':'même SHA', 'graphesfeatures':'graphes de fonctionnalités', 'sources/sha':'sources / SHA',
 'propositionSPDX':'proposition SPDX', 'simulationSPDX':'simulation SPDX', 'simulationSPDX':'simulation SPDX',
 '490 ids':'490 identifiants', 'la policy':'la politique', 'la policy':'la politique',
 'nom/version identiques':'nom/version identiques', 'nom/version ':'nom/version ',
 'héritageworkspace':'héritage du workspace', 'confiance0.8':'confiance 0.8', 'private.ignorefalse':'private.ignore=false',
 'include-devfalse/buildtrue':'include-dev=false / include-build=true', 'buildtrue':'build=true',
 '490 registry+quelleheureest0.0.1':'490 registry + quelleheureest 0.0.1',
 'cssparser0.37.0':'cssparser 0.37.0', 'cssparser-macros0.7.1':'cssparser-macros 0.7.1',
 'dtoa-short0.3.5':'dtoa-short 0.3.5', 'option-ext0.2.0':'option-ext 0.2.0', 'selectors0.38.0':'selectors 0.38.0',
 'ring0.17.14':'ring 0.17.14', 'Apache2 AND ISC':'Apache-2.0 AND ISC', 'MIT/Apache/LGPL':'MIT / Apache / LGPL',
 'prompt100%open-source':'prompt « 100 % open-source »', 'licensing-proposed-policy.toml':'licensing-proposed-policy.toml',
 'couvrent logiquement485/490':'couvrent logiquement 485/490', 'texteactuel':'texte actuel',
 'sansrésultat':'sans résultat', 'nonpubliés':'non publiés', 'missionlicences':'mission licences',
 'enlectureseule':'en lecture seule', 'rapportetannexes':'rapport et annexes', 'àcause':'à cause', 'd’envoisinterrompus':'d’envois interrompus',
 "d'envoisinterrompus":"d'envois interrompus", 'lescommentaires':'les commentaires', 'les3partiesoriginales':'les 3 parties originales',
 "N'appliqueaucune":"N'applique aucune", 'policy/licence/metadonnée/dépendance':'politique/licence/métadonnée/dépendance',
 'accordexplicite':'accord explicite', 'ghostcode':'code fantôme', 'optionaldeps':'dépendances optionnelles',
 'autoapprovalchange':"modification de l'approbation automatique", 'Le dossier comprend lespreuves':'Le dossier comprend les preuves',
 'rapportsantérieurs':'rapports antérieurs', 'relire le rapport licences/annexes':'relire le rapport licences et ses annexes',
 'licences actives':'licences actives', 'head vérifié est138':'head vérifié est 138',
 'alerteGitHub':'alerte GitHub', 'GitHubwrite':'GitHub en écriture', 'credential':'identifiant secret',
 'auto-approvalchange':"modification de l'approbation automatique", 'autoapproval':'approbation automatique',
 'graphesfeatures/cibles':'graphes de fonctionnalités/cibles', 'nativecomponents':'composants natifs',
 'ban/sourcechecks':'contrôles bans/sources', 'GitHubactuel':'GitHub actuel', 'cargo-deny0.20.2':'cargo-deny 0.20.2',
 'CodeQL CLI2.27.2':'CodeQL CLI 2.27.2', 'CLI2.27.2':'CLI 2.27.2', 'TOML parseOK':'Parsing TOML réussi',
 'sourcecase':'cas source', 'alerte#13':'alerte #13', 'HIGH#13':'HIGH #13', 'check115661038804':'check 115661038804',
 'fauxpositifduchemin':'faux positif du chemin', 'archive900':'archive, ligne 900', 'parcequenon':'parce que non',
 'uploadfalse':'upload=false', 'SHA256':'SHA-256', 'xxh32seed 0':'xxh32 seed 0', 'crates.io':'crates.io',
 'paquet/version':'paquet/version', 'sources/notices/EULA conformes':'sources/notices/EULA conformes',
 'cargo-deny réel':'cargo-deny réel', 'LicenseRef propre':'LicenseRef propre', 'licenceworkspace':'licence du workspace',
 'courslicences':'cours licences', 'réponsePR/commentaires':'réponses PR/commentaires', 'sourcesdistantes':'sources distantes',
 'copieupstream':'copie amont', 'sourcesamont':'sources amont', 'quelleheureest0.0.1':'quelleheureest 0.0.1',
 'paquetsconservés':'paquets conservés', 'avisnonmaintenance':'avis de non-maintenance', 'versionaudit':'audit de version',
 'métaapplication':'métadonnée applicative', 'Métadonnéeapplication':'Métadonnée applicative',
 'nonrésolue/nonexpositiondémontrée':'non résolue / exposition non démontrée', 'revoiramont':'revoir en amont',
 'Patchlocal':'Patch local', 'HIGHversion':'alerte HIGH de version', 'proposition nonappliquée':'proposition non appliquée',
 'CIrouge':'CI rouge', 'LICENSEpropriétaireexiste':'LICENSE propriétaire existe', 'relicenseautomatique':'changement automatique de licence',
 'nonreproductibles':'non reproductibles', 'pas nettoyées':'pas nettoyées', 'Non faite':'Non faite',
 'reprendreaprèslecture':'reprendre après lecture', 'Dernierverdictsécurité':'Dernier verdict sécurité',
 'nonprête':'non prête', 'avant9084.5s':'avant 9084.5 s', 'after9084.5s':'after 9084.5s', 'after5467.5s':'after 5467.5s',
 '20–35min':'20–35 min', 'ancien replay':'ancien replay', '22452caractères':'22 452 caractères',
 '450diagnostics':'450 diagnostics', '40sources':'40 sources', '491entrées':'491 entrées',
 '2.36Mo':'2,36 Mo', 'les497':'les 497', '485/490 expressions':'485/490 expressions',
 'les3':'les 3', '40sources':'40 sources', 'les14':'les 14', '14commentaires':'14 commentaires',
 'head/main/PR':'head/main/PR', 'rapportprincipal':'rapport principal', 'licences/annexes':'licences/annexes',
 'codeql/rust':'codeql/rust', 'stateGitHub':'état GitHub', 'ZIP artefact11869070736':'ZIP artefact 11869070736',
 'rapportsont':'rapports sont', 'lesrapports':'les rapports', 'leursSHA':'leurs SHA', 'ceSHA':'ce SHA',
 'aucun testn’est':'aucun test n’est', "aucun testn'est":"aucun test n'est", 'cettecopie':'cette copie',
 'Lesliensversjobs/artefacts':'Les liens vers jobs/artefacts', 'peuventexpirer':'peuvent expirer',
 'lespreuveslocales':'les preuves locales', 'rapportslicences':'rapports licences', 'leslogspublicsCI':'les logs publics CI',
 'LeslogspublicsCI':'Les logs publics CI', 'chaquepièce':'chaque pièce', 'Lesempreintes':'Les empreintes',
 "l'authenticitéjuridique":"l'authenticité juridique", "d'un upstreamni":"d'un amont ni", 'lescopieslocales':'les copies locales',
 'desblobGit':'des blobs Git', 'sontexteinitial':'son texte initial', 'commitsource':'commit source',
 'exportsSARIF':'exports SARIF', 'etlogs':'et logs', 'workflowdiagnostic':'workflow diagnostic',
 'la têtefuture':'la tête future', 'pas de preuveper-file':'pas de preuve fichier par fichier',
 'les497?':'les 497 ?', '485logiquement':'485 logiquement', '5MPL':'5 MPL',
 'ring0.17.14':'ring 0.17.14', 'commit2723':'commit 2723', 'MITANDISCANDOpenSSL':'MIT AND ISC AND OpenSSL',
 'PackageSpec exact@version':'PackageSpec exact @version', 'customLicenseRef/clarify':'LicenseRef personnalisé / clarify',
 'slash legacyOR':'slash historique OR', '24tests':'24 tests', 'chaquefichier':'chaque fichier',
 'stagesV8':'stores V8', 'storesV8':'stores V8', 'corpsde':'corps de', 'commentaireGitHub':'commentaire GitHub',
 'destête':'des têtes', 'parceque':'parce que', 'notices/MPL/EULA/nativecomponents':'notices/MPL/EULA/composants natifs',
 'enlectureseule':'en lecture seule', 'lire lescommentaires':'lire les commentaires',
 'JavaScript/Rustmigrations/alertdismissing':'JavaScript, les migrations Rust ou les changements d’état des alertes',
 'si demandée':'si demandée', 'décisionfinale':'décision finale', 'n’estpas':'n’est pas',
 'No threshold':'No threshold', 'rapportsantérieurs intégraux':'rapports antérieurs intégraux',
 'les3partiesoriginales':'les 3 parties originales', 'secret/.aws':'.aws',
 'lesscripts':'les scripts', 'lesconsignes':'les consignes', 'lesdiffs':'les diffs',
 'LeslogspublicsCI':'Les logs publics CI', 'sansmodification':'sans modification',
 'CodeQLanalyses':'analyses CodeQL', 'xxh32seed':'xxh32 seed', 'secretvariable':'variable secrète',
}
for a,b in sorted(fixes.items(), key=lambda kv:len(kv[0]), reverse=True): intro=intro.replace(a,b)
intro = intro.replace('Aucune valeuridentifiant secret/.aws/.codex', 'Aucune valeur de credential/.aws/.codex')
intro = intro.replace('observations_currenttrue', 'observations_current=true').replace('observed_phaserunning','observed_phase=running').replace('networkpolicyunrestricted/enforced','network_policy=unrestricted/enforced').replace('outboundidentities','outbound_identities')
intro = intro.replace('les497? **Attention : le chiffre correct est491 entrées, pas497.**', 'les **491 entrées, 490 registry et application**.')
for a,b in {
 'les14':'les 14', 'et14':'et 14', 'Les3parties':'Les 3 parties',
 'chacune<65536caractères':'chacune moins de 65 536 caractères',
 'inventaire490+application':'inventaire des 490 paquets tiers et de l’application',
 'preuves40':'preuves des 40 sources amont', 'maisnon publiés':'mais non publiés',
 'avec--locked':'avec --locked', 'copiesdocs':'copies de documents',
 'et450':'et 450', ';40':'; 40', 'notesnecontiennent':'notes ne contiennent',
 'aucune valeuridentifiant secret/.aws/.codex': 'aucune valeur de secret ni contenu de .aws/.codex',
 'MANIFEST_SHA-256.json':'MANIFEST_SHA256.json', 'SHA-256SUMS':'SHA256SUMS',
 'etSHA256SUMS':'et SHA256SUMS', 'lesURLs':'les URLs', 'letexteentier':'le texte entier',
 'Lesrapports':'Les rapports', 'desfaits':'des faits', 'avecSHA':'avec SHA',
 'Publicationrapportlicences':'Publication du rapport licences',
 'Histoiresnpm/multitool':'Verrous historiques npm et compatibilité multi-outils',
 'Préparationfusion':'Préparation de la fusion', 'erreur403':'erreur 403',
 'Tentative1':'Tentative 1', 'Tentative2':'Tentative 2',
 'direct/PATH/concurrence':'directe des archives, PATH et concurrence',
 'propremigration':'migration propre', 'policystill':'politique encore',
 'si une policy':'si une politique', 'une policy':'une politique',
 '20–35min':'20–35 min', 'de20–35':'de 20–35',
 'logs450':'logs 450', 'textes413':'textes 413',
 'sources/LF':'sources/LF', '491 entrées /446':'491 entrées / 446',
 '=490 registry':'= 490 registry', 'glyphbase':'base des glyphes',
 'TOML parsées':'propositions TOML parsées',
 'une réponsePR':'une réponse PR', 'fulltimeline':'timeline complète',
 'Github':'GitHub', 'HTTP200':'HTTP 200', 'HTTP2':'HTTP/2',
 '14commentaires':'14 commentaires', 'les3parties':'les 3 parties',
 'CWE476':'CWE-476', 'CWE825':'CWE-825',
 '1.34M':'1,34 Mo', '24+24 tests':'24 + 24 tests',
 'branchde':'branche de', 'leSHA':'le SHA',
}.items(): intro=intro.replace(a,b)
(root/'pr153-handoff-introduction.md').write_text(intro)
intro += '\n**Complément du relais :** la timeline GitHub complète a également été exportée : **44 entrées** (commentaires de conversation, commentaires inline et reviews), reproduites intégralement plus bas. Aucun rapport de licences ne figure dans ces entrées. Onze rapports Markdown référencés ont été relus au SHA distant et inclus avec leurs blobs.\n\n'

old = root/'licensing-report-comment.md'
backup = root/'licensing-report-comment.original-before-handoff.md'
if not backup.exists(): shutil.copy2(old,backup)
original = backup.read_text()
pr=json.loads((root/'pr153-handoff-pr.json').read_text())
comments=json.loads((root/'pr153-handoff-comments.json').read_text())
timeline=json.loads((root/'pr153-handoff-timeline.json').read_text())['comments']
remote=json.loads((root/'pr153-handoff-remote-reports.json').read_text())
full=intro+'\n'+original+'\n\n---\n\n'+(root/'licensing-inventory-comment.md').read_text()+'\n\n---\n\n'+(root/'licensing-evidence-comment.md').read_text()
full+='\n\n# 9. Description de PR actuelle — copie intégrale\n\n'+pr['body']
full+='\n\n# 10. Timeline GitHub complète — 44 entrées intégrales\n\nLes dates/types/champs complets sont aussi dans evidence/pr153-handoff-timeline.json. Aucun contenu de commentaire n’est raccourci.\n\n'
for i,c in enumerate(timeline,1):
 full+=f"\n\n---\n\n## Entrée {i} — ID {c['id']}\n\nURL : {c.get('url')}\n\nAuteur : {c.get('user')}\n\nDate : {c.get('created_at')} ; review : {c.get('review')} ; chemin : {c.get('path')} ; ligne : {c.get('line')}\n\n"+(c.get('body') or '(Corps vide ; métadonnées conservées dans le JSON.)')+'\n'
full+='\n\n# 11. Instructions et rapports distants au SHA 138f029 — copies intégrales\n\n'
for path,r in remote.items():
 s=r.get('structuredContent',{})
 if r.get('isError') or not s.get('content'): raise RuntimeError('Missing remote file '+path)
 full+=f"\n\n---\n\n## Fichier distant : {path}\n\nBlob Git : `{s.get('sha')}`\n\nSource : {s.get('display_url')}\n\n"+s['content']+'\n'

full+='\n\n# 12. Pièces brutes et vérification du paquet de relais\n\n'
full+='Les logs, SARIF, preuves JSON, anciennes notes, fixtures et copies historiques locales ne sont pas collés dans le Markdown pour éviter une transcription altérée ; leurs **fichiers complets** sont dans l’archive ZIP et l’index MANIFEST_SHA256.json. Les conclusions, rapports et commentaires sont tous inclus ci-dessus.\n\n'
full+='Le rapport principal original de licences à publier est **evidence/licensing-report-comment.original-before-handoff.md** ; les deux annexes sont **evidence/licensing-inventory-comment.md** et **evidence/licensing-evidence-comment.md**. Le nouveau rapport de relais excède la limite d’un commentaire GitHub ; ne pas utiliser licensing-report-comment.md comme corps de publication unique.\n\n'
full+='Vérifier les empreintes : `sha256sum -c SHA256SUMS` depuis la racine du dossier extrait. Cette commande lit les fichiers ; elle ne lance aucun générateur.\n\n'
full+='EN: Complete evidence-backed handoff, with full prior PR reports/timeline, current read-only licensing analysis, unpublished proposals, failed/interrupted publication attempts and explicit limitations. Earlier calls without surviving logs cannot be reconstructed honestly. No repository changes, licence-policy application, new GitHub publication or merge were made for this handoff.\n'

(root/'PR153_RELAIS_COMPLET_20261014.md').write_text(full)
old.write_text(full)
(out/'PR153_RELAIS_COMPLET_20261014.md').write_text(full)
(out/'README.md').write_text('Lire PR153_RELAIS_COMPLET_20261014.md. Toutes les propositions/scripts/fixtures sont inactifs. Ne pas les appliquer/exécuter automatiquement. Vérifier SHA256SUMS. Aucun secret de runtime collecté. Les copies LOCAL_NON_AUTORITATIVE sont partielles et ne remplacent pas un clone distant exact.\n')
evidence=out/'evidence'; evidence.mkdir(exist_ok=True)
prefixes=('licensing-','high-','CODEQL_HIGH_','codeql-high-','pr153-','stabilization-')
for f in root.iterdir():
 if f.is_file() and f.name.startswith(prefixes): shutil.copy2(f,evidence/f.name)
shutil.copy2(root/'build-pr153-handoff.py',evidence/'build-pr153-handoff.py')
# Inclure les documents locaux sans les prétendre identiques aux blobs distants.
for source, target in [(root/'QuelleHeureEst-Il.com/docs', out/'LOCAL_NON_AUTORITATIVE/docs'), (root/'scratch',out/'LOCAL_NON_AUTORITATIVE/scratch')]:
 if source.exists(): shutil.copytree(source,target,dirs_exist_ok=True,symlinks=True)
remote_dir=out/'REMOTE_PINNED_138f029'
for path,r in remote.items():
 dest=remote_dir/path; dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(r['structuredContent']['content'])
# README et prompt distants ont déjà été gardés dans le corpus amont du dernier audit.
ss=json.loads((root/'licensing-upstream-sources.json').read_text())
for key,path in [('project-readme','.github/README.md'),('project-prompt','.bolt/prompt'),('project-license','LICENSE'),('project-vendor-license','vendor/glib-0.18.5/LICENSE')]:
 dest=remote_dir/path; dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(ss[key]['content'])

files=[]
for f in sorted(out.rglob('*')):
 if f.is_symlink(): raise RuntimeError('Do not bundle a symlink: '+str(f))
 if f.is_file() and f.name not in ['MANIFEST_SHA256.json','SHA256SUMS']:
  data=f.read_bytes(); files.append({'path':str(f.relative_to(out)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(out/'MANIFEST_SHA256.json').write_text(json.dumps({'generated_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pr':153,'head':pr['head_sha'],'main':pr['base_sha'],'file_count':len(files),'files':files},ensure_ascii=False,indent=2)+'\n')
manifest_file=out/'MANIFEST_SHA256.json'
lines=[f"{r['sha256']}  {r['path']}" for r in files]+[hashlib.sha256(manifest_file.read_bytes()).hexdigest()+'  MANIFEST_SHA256.json']
(out/'SHA256SUMS').write_text('\n'.join(lines)+'\n')
archive=root/'PR153_RELAIS_COMPLET_20261014.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in sorted(out.rglob('*')):
  if f.is_file():z.write(f,str(Path(out.name)/f.relative_to(out)))
assert all(c.get('body','') in full for c in timeline)
assert original in full and (root/'licensing-inventory-comment.md').read_text() in full and (root/'licensing-evidence-comment.md').read_text() in full
assert all(r['structuredContent']['content'] in full for r in remote.values())
for r in files: assert hashlib.sha256((out/r['path']).read_bytes()).hexdigest()==r['sha256']
with zipfile.ZipFile(archive) as z: assert z.testzip() is None
print(json.dumps({'head':pr['head_sha'],'conversation_comments':len(comments),'timeline_entries':len(timeline),'remote_files':len(remote),'report_chars':len(full),'evidence_files':len(files),'zip_bytes':archive.stat().st_size,'zip_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'checks':'all full bodies present; copied files hashes match; zip CRC check passed'},ensure_ascii=False,indent=2))
