import json, re, hashlib, collections, tomllib
from pathlib import Path
base=Path('/workspace')
pkgs=json.loads((base/'licensing-lock-packages.json').read_text())
rej=json.loads((base/'licensing-rejections.json').read_text())
extra=json.loads((base/'licensing-additional-packages.json').read_text())
sources=json.loads((base/'licensing-upstream-sources.json').read_text())
records=[dict(r,status='R') for r in rej]+[dict(r,status='H') for r in extra]
assert len(records)==490 and len({(r['name'],r['version']) for r in records})==490
assert {(r['name'],r['version']) for r in records}=={(p['name'],p['version']) for p in pkgs if 'source' in p}
allow={'MIT','Apache-2.0','BSD-3-Clause','ISC','Zlib','Unicode-3.0','Apache-2.0 WITH LLVM-exception'}
def evaluate(expr):
 tokens=re.findall(r'\(|\)|AND|OR|WITH|[A-Za-z0-9.-]+',expr.replace('/',' OR ')); pos=0
 def atom():
  nonlocal pos
  if tokens[pos]=='(':
   pos+=1; val=orexp(); assert tokens[pos]==')';pos+=1;return val
  key=tokens[pos];pos+=1
  if pos<len(tokens) and tokens[pos]=='WITH': key+=' WITH '+tokens[pos+1];pos+=2
  return key in allow
 def andexp():
  nonlocal pos
  val=atom()
  while pos<len(tokens) and tokens[pos]=='AND':pos+=1; other=atom();val=val and other
  return val
 def orexp():
  nonlocal pos
  val=andexp()
  while pos<len(tokens) and tokens[pos]=='OR':pos+=1;other=andexp();val=val or other
  return val
 val=orexp();assert pos==len(tokens);return val
remaining=[r for r in records if not evaluate(r['license_raw'])]
assert len(remaining)==5 and all(r['license_raw']=='MPL-2.0' for r in remaining)
def xxh32(data):
 p1,p2,p3,p4,p5=2654435761,2246822519,3266489917,668265263,374761393; mask=0xffffffff
 def rot(v,n):return ((v<<n)|(v>>(32-n)))&mask
 def rnd(v,x):return rot((v+x*p2)&mask,13)*p1&mask
 i=0
 if len(data)>=16:
  vs=[(p1+p2)&mask,p2,0,(-p1)&mask]
  while i<=len(data)-16:
   for j in range(4):vs[j]=rnd(vs[j],int.from_bytes(data[i:i+4],'little'));i+=4
  h=sum(rot(v,n) for v,n in zip(vs,[1,7,12,18]))&mask
 else:h=p5
 h=(h+len(data))&mask
 while i<=len(data)-4:h=rot((h+int.from_bytes(data[i:i+4],'little')*p3)&mask,17)*p4&mask;i+=4
 while i<len(data):h=rot((h+data[i]*p5)&mask,11)*p1&mask;i+=1
 h^=h>>15;h=h*p2&mask;h^=h>>13;h=h*p3&mask;h^=h>>16;return h
assert xxh32(b'')==0x02cc5d05 and xxh32(b'a')==0x550d7456
lic=sources['project-license']['content']
normalized=''.join(line.rstrip('\r\n')+'\n' for line in lic.splitlines(keepends=True)).encode()
policy='''# Proposition non appliquée / Unapplied proposal
[licenses]
allow = ["MIT", "Apache-2.0", "BSD-3-Clause", "ISC", "Zlib",
         "Unicode-3.0", "Apache-2.0 WITH LLVM-exception"]
confidence-threshold = 0.8
include-build = true
# Étendre le contrôle aux tests / Include test-only dependencies
include-dev = true
# Uniquement après accord et procédure MPL / Only after approval and MPL process
exceptions = [
  { crate = "cssparser@0.37.0", allow = ["MPL-2.0"] },
  { crate = "cssparser-macros@0.7.1", allow = ["MPL-2.0"] },
  { crate = "dtoa-short@0.3.5", allow = ["MPL-2.0"] },
  { crate = "option-ext@0.2.0", allow = ["MPL-2.0"] },
  { crate = "selectors@0.38.0", allow = ["MPL-2.0"] },
  # Identifie le texte existant sans le modifier / Identifies existing unchanged text
  { crate = "quelleheureest@0.0.1", allow = ["LicenseRef-Phoen0x-Proprietary"] },
]
[licenses.private]
ignore = false

[[licenses.clarify]]
crate = "quelleheureest@0.0.1"
expression = "LicenseRef-Phoen0x-Proprietary"
license-files = [{ path = "../LICENSE", hash = HASH }]
'''.replace('HASH',f'0x{xxh32(normalized):08x}')
tomllib.loads(policy)
(base/'licensing-proposed-policy.toml').write_text(policy)
groups=collections.defaultdict(list)
for r in records:groups[r['license_raw']].append(r)
inventory='''## Audit licences — annexe 1 : inventaire intégral du Cargo.lock actif

Commit audité : `138f029e44c4b63abef8d5315845b360814f76f3`.

**491 entrées = 490 paquets registry + quelleheureest 0.0.1 ; 446 noms distincts.** Toutes les versions sont conservées, y compris les variantes de plateforme, build, développement et optionnelles représentées par ce lock. Ce tableau décrit les licences déclarées, pas une certification de chaque fichier ni de chaque bibliothèque native.

**R** : 450 rejets réellement observés, tous pour `license is not explicitly allowed`, faute d'allowlist. **H** : 40 entrées supplémentaires du verrou, absence dans ces rejets ; déclaration vérifiée dans un manifeste amont de même nom/version (annexe 2). H ne signifie ni acceptation cargo-deny ni dépendance inutile. `/` est conservé tel que déclaré ; le parseur SPDX lax utilisé le traite comme OR.

Chaque groupe associe l'expression déclarée à tous ses noms/versions ; les obligations figurent au rapport principal. Preuve des R : [job cargo-deny 115672063173](https://github.com/Phoen0x/QuelleHeureEst-Il.com/actions/runs/38508720134/job/115672063173), avec ligne du `license` et diagnostic pour chaque paquet. Preuve des versions/checksums : [Cargo.lock](https://github.com/Phoen0x/QuelleHeureEst-Il.com/blob/138f029e44c4b63abef8d5315845b360814f76f3/Cargo.lock).

'''
for expr,rs in sorted(groups.items()):
 inventory+=f'### `{expr}` — {len(rs)} versions\n\n'
 for status in ['R','H']:
  rr=[r for r in rs if r['status']==status]
  if rr:inventory+=f'**{status} ({len(rr)})** : '+', '.join('`'+r['name']+'@'+r['version']+'`' for r in sorted(rr,key=lambda r:(r['name'],r['version'])))+'.\n\n'
inventory+='### Paquet applicatif — U\n\n`quelleheureest@0.0.1` : `error[unlicensed]`, manifeste sans `license`/`license-file`, `publish=false`. Le texte propriétaire racine existe ; le défaut est la reconnaissance machine, pas une mise dans le domaine public. Ne pas ajouter MIT/Unlicense sans décision de licence.\n\nEN: Full locked-package metadata inventory; R = observed empty-allowlist rejection, H = matching upstream declaration outside the rejection set, U = missing application machine-readable metadata. No package was removed or reactivated.\n'
(base/'licensing-inventory-comment.md').write_text(inventory)
annex='''## Audit licences — annexe 2 : preuves amont des 40 entrées hors des rejets CI

Les 450 autres déclarations proviennent directement des manifestes registry affichés par cargo-deny dans le job cité. Pour ces 40 entrées du lock, le nom **et la version** ont été vérifiés dans les sources amont ; une licence héritée du workspace a été résolue. Les archives crates.io n'ont pas pu être téléchargées dans cet environnement : leurs checksums du Cargo.lock n'ont donc pas été revérifiés par téléchargement. Cette limite est explicite ; aucune acceptation par le moteur cargo-deny n'est déduite de leur absence des 450 rejets.

| Paquet | Expression déclarée | Manifeste amont et blob Git | Héritage workspace |
|---|---|---|---|
'''
for r in sorted(extra,key=lambda r:(r['name'],r['version'])):
 annex+=f"| `{r['name']}@{r['version']}` | `{r['license_raw']}` | [source]({r['url']}) — `{r['manifest_blob']}` | "+(f"[workspace]({r['workspace_url']})" if r.get('workspace_url') else '—')+' |\n'
annex+='\nEN: Matching-version upstream evidence for all 40 lock entries outside the observed CI rejection set; registry archive checksum verification remains outstanding.\n'
(base/'licensing-evidence-comment.md').write_text(annex)
print(json.dumps({'records':len(records),'rejected':len(rej),'extra':len(extra),'policy_logical_pass':490-len(remaining),'remaining':[(r['name'],r['version']) for r in remaining],'license_normalized_sha256':hashlib.sha256(normalized).hexdigest(),'license_xxhash32':f'0x{xxh32(normalized):08x}','inventory_chars':len(inventory),'evidence_chars':len(annex)},indent=2))
